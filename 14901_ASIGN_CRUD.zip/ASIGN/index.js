const path=require('path');
const express=require('express');
const mysql=require('mysql');
const bodyParser = require('body-parser'); //It is responsible for parsing the incoming request bodies in a middleware before you handle it.
const ejs=require('ejs');
const e = require('express');

const app=express();     //The app object is instantiated on creation of the Express server
const port=8080;

const con = mysql.createConnection({  //inside this we pass connection details 
    host: 'localhost',         
    user: 'root',
    password: '12345',
    database: 'it_assignment'
});

con.connect( (err) => {               //call connect function for con object 
    if (err) {
	console.error('some error occured while connecting');
	process.exit(1);
    }
    console.log('Connection established.');
});

//set views file
app.set('views',path.join(__dirname,'views'));
 
//set view engine
app.set('view engine', 'ejs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.get('/',(req, res) => {
    res.render('index', {
                title : 'WELCOME TO STUDENT PORTAL',
             
            });

});

app.get('/add',(req, res) => {
    res.render('index', {
        title : 'WELCOME TO STUDENT PORTAL'
    });
});

app.post('/submit',(req, res) => { 
    var sql="insert into student_info values('"+req.body.student_id+"','"+req.body.name+"','"+req.body.age+"','"+req.body.gender+"','"+req.body.course+"','"+req.body.email+"','"+req.body.marks_1+"','"+req.body.marks_2+"','"+req.body.marks_3+"','"+req.body.marks_4+"','"+req.body.marks_5+"')"
    con.query(sql,(err,rows) => {
      if(err) {
         console.log("there is some error vndf");
      }
      else{
        console.log(req.body);
       
      }
     
    });
});
app.get('/display',(req, res) => {
    let sql = "SELECT * FROM student_info";
    con.query(sql, (err, rows) => {
        if(err){
            console.log("display error");
        }
        res.render('result', {
            title : 'ALL DETAILS',
            users : rows
        });
    });
});

app.get('/edit/:studentId',(req, res) => {
    const studentId = req.params.studentId;
    let sql = `Select * from student_info where student_id = ${studentId}`;
    let query = con.query(sql,(err, result) => {
        if(err) throw err;
        res.render('update', {
            title : 'EDIT TEMPLATE',
            user : result[0]
        });
    });
});

app.post('/update',(req, res) => {
    const studentId= req.body.student_id;
    let sql = "update student_info SET  name='"+req.body.name+"', age='"+req.body.age+"', gender='"+req.body.gender+"', course='"+req.body.course+"', email='"+req.body.email+"', marks_1='"+req.body.marks_1+"', marks_2='"+req.body.marks_2+"', marks_3='"+req.body.marks_3+"', marks_4='"+req.body.marks_4+"', marks_5='"+req.body.marks_5+"'where student_id ="+studentId;
    // where student_id ="+studentId
    let query = con.query(sql,(err) => {
        if(err) throw err;
         else{
           console.log(req.body)
           res.redirect('/display');
         }
        
    });
});

app.get('/delete/:studentId',(req, res) => {
    const studentId = req.params.studentId;
    let sql = `DELETE from student_info where student_id = ${studentId}`;
    let query = con.query(sql,(err, result) => {
        if(err) throw err;
        res.redirect('/display');
    });
});

// Server Listening
app.listen(port, () => {
    console.log('Server is running at port 8080');
});


// app
//    .use(express.static('views'))
//    .use(bodyParser.urlencoded({extended:false}))
//    .use(bodyParser.json())
//    .set('views',path.join('/ASIGN','views'))
//    .set('view engine','ejs')

//    .get('/submit',(req,res)=>{
//        res.render('result')
//    })
//    .post('/submit',(req,res)=>{
       
//         console.log(req.body);
//         var sql="insert into students_info values('"+req.body.name+"','"+req.body.age+"','"+req.body.gender+"','"+req.body.course+"','"+req.body.email+"','"+req.body.student_id+"','"+req.body.marks1+"','"+req.body.marks2+"','"+req.body.marks3+"','"+req.body.marks4+"','"+req.body.marks5+"')"
//         con.query(sql,function(err){
//             if (err) {
//                 console.log('their is some error');
//             }
//             else{
//                 console.log("helo");
//                 res.writeHead(302, {
//                     location: "result"
//                     }).end();
//                 }
//                 // res.end("Hello " + req.body.name + ", Your details added successfully. \n Here you can check \n"+"Age ="+req.body.age+"\nGender ="+req.body.gender+"\nCourse ="+req.body.course+"\nEmail-ID ="+req.body.email+"\nStudent-ID ="+req.body.student_id+"\nMarks obtained in different subject"+"\nMarks 1 ="+req.body.marks1+"\nMarks 2 ="+req.body.marks2+"\nMarks 3 ="+req.body.marks3+"\nMarks 4 ="+req.body.marks4+"\nMarks 5 ="+req.body.marks5);
              
         
//         })
//    })
//    .listen(port,()=>console.log('Server listening on port ${port}'));